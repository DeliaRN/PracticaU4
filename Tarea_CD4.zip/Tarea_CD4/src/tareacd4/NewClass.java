
package tareacd4;

public class NewClass {
    
}
